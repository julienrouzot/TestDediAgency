<?php

class Model{
    public $bdd = null;

    private static $instance = null;

    public function __construct(){
        if(DEBUG){
            $PDO_MODE = array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_WARNING);
        }else{
            $PDO_MODE = array();
        }
        if(is_null(self::$instance))
            $this->bdd = new PDO('mysql:dbname='.DB_DATABASE.';host='.DB_HOST,DB_USER, DB_PASS, $PDO_MODE);
    }

    public static function getInstance(){
        if(is_null(self::$instance))
            self::$instance = new Model();
        return self::$instance;
    }

    public function populate($data){
        foreach($data as $key=>$val){
            if(property_exists($this, $key)){
                $this->$key = $val;
            }
        }
    }

    public function attach(SplObserver $observer)
    {
        $this->observers[] = $observer;
    }

    public function detach(SplObserver $observer)
    {
        if (is_int($key = array_search($observer, $this->observers, true)))
        {
            unset($this->observers[$key]);
        }
    }

    public function notify()
    {
        foreach ($this->observers as $observer)
        {
            $observer->update($this);
        }
    }
}