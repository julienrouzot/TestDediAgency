<?php

class UserModel extends Model implements SplObserver{
    public static $tableName='users';

    public $id_user;
    public $username;
    public $passwd;

    public function __construct($id_user = null){
        parent::__construct();
        if(!is_null($id_user)){
            $req = $this->bdd->prepare('SELECT * FROM '.self::$tableName.' WHERE id_user=:id_user');
            $req->bindValue('id_user', $id_user);
            $req->execute();
            $data = $req->fetch();
            $this->populate($data);
        }
    }

    public static function getAll(){
        $model = Model::getInstance();
        $req = $model->bdd->prepare('SELECT * FROM '.self::$tableName);
        $req->execute();
        $users = $req->fetchAll();
        $aUsers = array();
        foreach($users as $user){
            $c = new UserModel();
            $c->populate($user);
            $aUsers[] = $c;
        }
        return $aUsers;
    }

    public function testUser(){
        $ret = false;

        if(isset($_POST['username']) && isset($_POST['passwd']))
        {
            $username =   $_POST['username'];
            $passwd = $_POST['password'];
            $passwd = hash("sha256", $passwd);

            $req = $this->bdd->prepare('SELECT id_user FROM '.self::$tableName.' WHERE username = :username AND passwd = :passwd');
            $req->bindValue('username', $username);
            $req->bindValue('passwd', $passwd);
            $ret = $req->execute();

            return $ret;

            /*if($req->rowCount() == 0){
                echo "Nom d\'utilisateur ou mot de passe invalide !";
            }

            else{
                session_start();
                $_SESSION['user'] = $_POST['user'];
                header('Location: index.php');
            }*/
        }

    }

    public function save(){
        $ret = false;
        if($this->id_user){//
            //update
            $req = $this->bdd->prepare('UPDATE '.self::$tableName.' SET username=:username, passwd=:passwd, active=:active WHERE id_user=:id_user');
            $req->bindValue('id_user', $this->id_user);
            $req->bindValue('username', $this->username);
            $req->bindValue('passwd', $this->passwd);

            $ret = $req->execute();
        }else{
            $req = $this->bdd->prepare('INSERT INTO '.self::$tableName.' (passwd, username) VALUES (:username, :passwd)');

            $req->bindValue('username', $this->username);
            $req->bindValue('passwd', $this->passwd);
            $ret = $req->execute();
        }
        return $ret;
    }

    public function delete(){
        $req = $this->bdd->prepare('DELETE FROM '.self::$tableName.' WHERE id_user=:id');
        $req->bindValue('id_user', $this->id_user);
        $ret = $req->execute();
        return $ret;
    }

    public function update(SplSubject $obj){
        echo 'User a été notifié ! Nouvelle valeur de l\'attribut <strong>contenu</strong> : ', $obj->getContenu();
    }
}
