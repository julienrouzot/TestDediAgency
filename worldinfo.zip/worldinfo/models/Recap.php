<?php

class RecapModel extends Model implements SplObserver{
    public static $tableName='intervention';

    public $id_intervention;
    public $inte_user;
    public $numSalle;
    public $description;
    public $remarque;
    public $datedemande;
    public $suivi;

    public function __construct($id_intervention = null){
        parent::__construct();
        if(!is_null($id_intervention)){
            $req = $this->bdd->prepare('SELECT * FROM '.self::$tableName.' WHERE id_intervention=:id_intervention');
            $req->bindValue('id_intervention', $id_intervention);
            $req->execute();
            $data = $req->fetch();
            $this->populate($data);
        }
    }

    public static function getAll(){
        $model = Model::getInstance();
        $req = $model->bdd->prepare('SELECT * FROM '.self::$tableName);
        $req->execute();
        $interventions = $req->fetchAll();
        $aInterventions = array();
        foreach($interventions as $intervention){
            $c = new RecapModel();
            $c->populate($intervention);
            $aInterventions[] = $c;
        }
        return $aInterventions;
    }

    public function save(){
        $ret = false;
        if($this->id_intervention){//
            //update
            $req = $this->bdd->prepare('UPDATE '.self::$tableName.' SET id_intervention=:id_intervention, inte_user=:inte_user, numSalle=:numSalle, description=:description, remarque=:remarque, datedemande=:datedemande, suivi=:suivi WHERE id_intervention=:id_intervention');
            $req->bindValue('id_intervention', $this->id_intervention);
            $req->bindValue('inte_user', $this->inte_user);
            $req->bindValue('numSalle', $this->numSalle);
            $req->bindValue('description', $this->description);
            $req->bindValue('remarque', $this->remarque);
            $req->bindValue('datedemande', $this->datedemande);
            $req->bindValue('suivi', $this->suivi);
            $ret = $req->execute();
        }else{
            $req = $this->bdd->prepare('INSERT INTO '.self::$tableName.' (inte_user, numSalle, description, remarque, datedemande, suivi) VALUES (:inte_user, :numSalle, :description, :remarque, :datedemande, :suivi)');
            $req->bindValue('inte_user', $this->inte_user);
            $req->bindValue('numSalle', $this->numSalle);
            $req->bindValue('description', $this->description);
            $req->bindValue('remarque', $this->remarque);
            $req->bindValue('datedemande', $this->datedemande);
            $req->bindValue('suivi', $this->suivi);
            $ret = $req->execute();
        }
        return $ret;
    }

    public function delete(){
        $req = $this->bdd->prepare('DELETE FROM '.self::$tableName.' WHERE id_intervention=:id_intervention');
        $req->bindValue('id_intervention', $this->id_intervention);
        $ret = $req->execute();
    }

    public function update(SplSubject $obj){
        echo 'Article a été notifié ! Nouvelle valeur de l\'attribut <strong>contenu</strong> : ', $obj->getContenu();
    }
}
