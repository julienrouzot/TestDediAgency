<!DOCTYPE html>
<html lang="fr">
<head>
    <title>WorldInfo</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
</head>
<body>
<div class="container-contact100">
    <div class="wrap-contact100">
        <form method="POST" action="recap">
				<span class="contact100-form-title">
					Demande d'intervention
				</span>


            Votre nom
            <input class="input100" type="text" name="name" placeholder="Your name" required>
            <br>

            Bureau n° :
            <input class="input100" type="text" name="bureau" placeholder="Exemple : B258 " required>

            <br>
            Votre problème concerne : <br>
            <table>
                <tr>
                    <td>
                        <br>
                        <input type= "radio" name="pbconcerne" value="Un ou plusieurs ordinateur(s)"> Un ou plusieurs ordinateur(s)
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type= "radio" name="pbconcerne" value="Tous les ordinateurs"> Tous les ordinateurs
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type= "radio" name="pbconcerne" value=" Une imprimante"> Une imprimante
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type= "radio" name="pbconcerne" value="Autre"> Autre
                        <br>
                    </td>
                </tr>
                <br>
            </table>
            <br><br><br><br>


            Eventuellement, saisissez le ou les numéro(s) d'ordinateur(s) qui vous pose(nt) un problème
            <input class="input100" type="text" name="prob" placeholder="Your message here..." required>

            <br>


                Décrivez précisement votre problème
                <textarea class="input100" name="description" placeholder="Your message here..." required></textarea>
                <button class="contact100-form-btn" name="validate">
						    <span>
							           Valider
					    	</span>
                </button>

        </form>
    </div>
</div>

</body>
</html>
