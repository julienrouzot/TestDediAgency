<!DOCTYPE html>
<html lang="fr">
<head>
    <title>WorldInfo - Recap</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
</head>
<body>
<div class="container-contact100">
    <div class="wrap-contact100">
        <form method="POST" action="recap/insertProblem">
				<span class="contact100-form-title">
					Récapitulatif
				</span>


            Votre nom
            <input class="input100" type="text" name="name" value="<?php echo $name; ?>" readonly>
            <br>

            Bureau n° :
            <input class="input100" type="text" name="bureau" value="<?php echo $bureau; ?>" readonly>

            <br>

            <textarea class="input100" name="prob" readonly> <?php echo " " . $pbconcerne . " : " . $prob; ?></textarea>

            <br>



                <textarea class="input100" name="description" readonly><?php echo $description; ?></textarea>
                <button class="contact100-form-btn" name="validate">
						    <span>
							           Valider
					    	</span>
                </button>

        </form>
    </div>
</div>

</body>
</html>
