<html>
<head>
    <title>Connexion</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
</head>

<body>
<div class="login-page">
    <div class="form">
          <img style="width:100%" src="../img/logo.png" alt="logo worldinfo sav">
        <form class="login-form" method="POST" action="connect">
            <input type="text" name="username" placeholder="Username : admin" required/>
            <input type="password" name="password" placeholder="Mot de passe : azerty123" required/>
            <button id="button" type="submit" name="submit">Suivant</button>
        </form>
    </div>
</div>
</body>
</html>
