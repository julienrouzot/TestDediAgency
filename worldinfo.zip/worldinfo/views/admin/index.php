<!doctype html>
<html lang="fr">
<head>
    <title>Admin interface</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
    <style>
      #customers {
          font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
          border-collapse: collapse;
          width: 100%;
      }

      #customers td, #customers th {
          border: 1px solid #ddd;
          padding: 8px;
      }

      #customers tr:nth-child(even){background-color: #f2f2f2;}

      #customers tr:hover {background-color: #ddd;}

      #customers th {
          padding-top: 12px;
          padding-bottom: 12px;
          text-align: left;
          background-color: #6b6c94;
          color: white;
      }
</style>
</head>
<body>

<nav class="navbar navbar-expand-sm bg-light">

    <!-- Links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" href="disconnect">Déconnexion</a>
        </li>
    </ul>

</nav>

<table id="customers">
<tr>
  <th></th>
  <th>Num</th>
  <th>Salle</th>
  <th>Description</th>
  <th>Remarques</th>
  <th>Demandée le</th>
  <th>Suivi</th>
</tr>
<?php
foreach($interventions as $intervention){
  echo "<tr><td><form action='admin/voir' method='post'><button type='submit' value='".$intervention->id_intervention ."' name='id'>Voir</button></td>";
  echo "<td>".$intervention->id_intervention."</td>";
  echo "<td>".$intervention->numSalle."</td>";
  echo "<td>".$intervention->description."</td>";
  echo "<td>".$intervention->remarque."</td>";
  echo "<td>".$intervention->datedemande."</td>";
  if($intervention->suivi==0){ echo "<td> En cours </td>"; }else{ echo "<td> Réparé </td>";}

}

?>
</tr>
</table>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
</body>
</html>
