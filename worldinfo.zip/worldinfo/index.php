<?php

//on définit les constantes qui nous permettrons d'inclure nos fichier n'importe où
define('WEBROOT', str_replace('index.php', '', $_SERVER['SCRIPT_NAME']));
define('ROOT', str_replace('index.php', '', $_SERVER['SCRIPT_FILENAME']));

//on inclu le coeur de notre MVC
require(ROOT . 'core/core.php');
require(ROOT . 'core/controller.php');
require(ROOT . 'core/model.php');

$controller = 'accueil';
$action = 'index';
if(isset($_GET['page']) && $_GET['page'] != ''){
    //isoler le controller et l'action
    $data = explode('/', $_GET['page']);
    $controller = $data[0];
    $action = isset($data[1]) && $data[1] != ''?$data[1]:$action;
}
//projet => ProjetController
$controller = ucfirst($controller).'Controller';
if(class_exists($controller)){
    if(method_exists($controller, $action)){
        $inst = new $controller();
        $inst->$action();
    }else{
        echo 'Action '.$action. ' not found in '.$controller;
    }
}else{
    echo 'Class '.$controller. ' not found';
}