<?php

class UserController extends Controller{

    public function index(){
        $users = UserModel::getAll();
        $this->set(array('users'=>$users));
        $this->render('index');
    }
}

