<?php
// Return Index
class AccueilController extends Controller{

    public function index(){
        $this->render('index');
    }
}
