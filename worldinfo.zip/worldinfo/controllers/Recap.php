<?php

class RecapController extends Controller{

    public function index(){
        if(isset($_POST['validate']))
        {
            $name = $_POST['name'];
            $bureau = $_POST['bureau'];
            $pbconcerne = $_POST['pbconcerne'];
            $prob = $_POST['prob'];
            $description = $_POST['description'];

            $this->set(array('name' => $name, 'bureau' => $bureau, 'pbconcerne' => $pbconcerne, 'prob' => $prob, 'description' => $description));
            $this->render('index');
        }
    }

    public function insertProblem(){
        $recap = new RecapModel();

        $recap->inte_user = $_POST['name'];
        $recap->numSalle = $_POST['bureau'];
        $recap->description = $_POST['description'];
        $recap->remarque = $_POST['prob'];
        $recap->datedemande = '2018-01-22';
        $recap->suivi = 0;
        $recap->save();


        echo "Votre demande d intervention a été traité avec succès ! <a href='".WEBROOT."' title='retour page d'accueil'>Retour à la page d'accueil</a>";
    }
}
