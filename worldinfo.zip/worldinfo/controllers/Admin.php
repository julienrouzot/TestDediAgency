<?php

class AdminController extends Controller{

    public function index(){
        $users = UserModel::getAll();
        $this->set(array('users'=>$users));

        session_start();
        //Si la session n'est pas démarré, la page est redirigé vers l'interface de connexion
        if(!isset($_SESSION['user'])) {
            header('Location: ' . WEBROOT . 'admin/login');
        }
        else{
            $interventions = RecapModel::getAll();
            $this->set(array('interventions'=>$interventions));
            $this->render('index');
        }
    }

    public function login(){
        $this->render('login');
    }

    public function connect(){
        $users = UserModel::getAll();

        if(isset($_POST['submit']))
        {
            $username =   $_POST['username'];
            $pass = $_POST['password'];
            $pass = hash("sha256", $pass);

            foreach($users as $user){
                if($username == $user->username && $pass == $user->passwd){
                    session_start();
                    $_SESSION['user'] = $username;
                    header('Location: ' . WEBROOT . 'admin/');
                }
                else{
                    echo "Nom d'utilisateur ou mot de passe invalide !";
                }
            }
        }
    }

    public function voir(){
        $recap = new RecapModel($_POST['id']);
        $recap->suivi = 1;
        $recap->save();
        header('Location: ' . WEBROOT . 'admin');
    }

    public function disconnect(){
        session_start();
        session_destroy();
        header('Location: ' . WEBROOT);
    }
}
